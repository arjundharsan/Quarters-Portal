# NIT Trichy Quarters Allotment Portal — Prototype

A static browser prototype for validating the quarters allotment workflow. It uses fictional sample data and is not an official NITT system.

## Run it
1. Extract the ZIP file.
2. Open `index.html` in Chrome, Edge, or Firefox.
3. Navigate using the tabs.
4. In **Import / Export**, download the CSV template. For inventory in Excel, use **Save As → CSV UTF-8 (Comma delimited)** and import the CSV.
5. Use Export buttons to download demo CSV files.

## Included
- Admin dashboard with inventory counts and status chart
- Search/filter quarters inventory
- Add fictional inventory records and cycle demo status
- Demo application queue and status changes
- Allotment stage tracker reflecting the traditional EMD process: circular, applications, eligibility, Establishment seniority, final eligible list, Director approval, declaration, order and registers
- Employee self-service application form and demo status lookup
- CSV inventory import and CSV export

## Important limitations
- No login or identity verification
- No server/database; browser data is temporary
- No secure document uploads, emails, or notifications
- No official eligibility decisions or production allotment workflow; workflow stages are demonstrative only
- No production-grade audit logs, backups, or access control
- The prototype should not be used with confidential employee data

## Suggested production architecture
- Frontend: React or another maintained web framework
- Authentication: institute-approved identity provider / SSO
- Backend: institution-approved API service
- Database: institution-approved relational database (e.g. PostgreSQL)
- Roles: EMD administrator, allotment staff, employee self-service, read-only/audit
- Security: server-side authorization, audit logs, backups, encryption, retention policy
- Deployment: institute-approved domain and hosting. GitHub stores source code and can support CI/CD; GitHub Pages alone is not suitable for private data workflows.

## Suggested CSV columns
`quarter,category,zone,status,occupant`
For the eventual full system, consider also `occupation_date,vacation_date,license_fee,water_charge,remarks`, with validation and policy rules approved by NITT.
